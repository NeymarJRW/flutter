import 'package:flutter/material.dart';
class GlobalConfig{

  static String title='title'; 
  static int currentIndex = 0;
  static List datelist=new List();
  static String str = 'hello';
  static ThemeData themeData ;
  static bool iconflag = true;
  static Color bgColor = Colors.black;
}